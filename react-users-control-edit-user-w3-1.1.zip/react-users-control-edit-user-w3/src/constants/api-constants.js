export const BASE_URL = 'https://jsonplaceholder.typicode.com/';
export const USERS = 'users/';