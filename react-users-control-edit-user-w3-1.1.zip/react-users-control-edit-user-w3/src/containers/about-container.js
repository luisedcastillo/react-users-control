import React from 'react';

const AboutContainer = () => (
    /* jshint ignore:start */ // JSX is not supported
    <div>About</div>
    /* jshint ignore:start */ // JSX is not supported
);

export default AboutContainer;